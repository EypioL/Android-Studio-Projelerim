package com.example.random;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private ToggleButton toggleTopla, toggleCarp, toggleFark, toggleBol;
    private TextView txtSoru;
    private EditText editTextTahmin;
    private ArrayList<String> islemTurleri;
    private Random rndIslem, rndSayi;
    private int rndIslemNumber, rndSayiNumber;
    private String soru, txtTahmin;
    private int s1, s2, sonuc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        islemTurleri = new ArrayList<>();
        rndIslem = new Random();
        rndSayi = new Random();
        toggleTopla= (ToggleButton) findViewById(R.id.toggleButtonTopla);
        toggleCarp= (ToggleButton) findViewById(R.id.toggleButtonCarp);
        toggleFark= (ToggleButton) findViewById(R.id.toggleButtonCikar);
        toggleBol= (ToggleButton) findViewById(R.id.toggleButtonBol);
        txtSoru= (TextView) findViewById(R.id.textViewSoru);
        editTextTahmin= (EditText) findViewById(R.id.editTextTahmin);

        toggleTopla.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b)
                    islemTurleri.add("+");
                else
                    islemTurleri.remove("+");
            }
        });
        toggleCarp.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b)
                    islemTurleri.add("*");
                else
                    islemTurleri.remove("*");
            }
        });
        toggleFark.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b)
                    islemTurleri.add("-");
                else
                    islemTurleri.remove("-");
            }
        });
        toggleBol.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b)
                    islemTurleri.add("/");
                else
                    islemTurleri.remove("/");
            }
        });
    }
    public void btnClick(View v){
        switch (v.getId()){
            case R.id.btnSoruGetir:
                txtSoru.setText(İslemTurunuVeSoruyuBelirle());
                break;

            case R.id.btnTahmindeBulunun:
                tahminKontrol();
                break;
        }
    }
    private void tahminKontrol() {
        txtTahmin = editTextTahmin.getText().toString();

        if (!TextUtils.isEmpty(txtTahmin)) {
            if (txtTahmin.matches(String.valueOf(sonuc))) {
                System.out.println("Tebrikler Doğru Tahminde Bulundunuz :))");
                editTextTahmin.setText("");
                txtSoru.setText(İslemTurunuVeSoruyuBelirle());
            } else

                System.out.println("Yanlış Tahminde Bulundunuz :((");
        }
        else
            System.out.println("Girilen Tahmin Değeri Boş Bırakılamaz.");
    }

    private String İslemTurunuVeSoruyuBelirle() {
        soru = " ";

        if (islemTurleri.size() > 0) {
            rndIslemNumber = rndIslem.nextInt(islemTurleri.size());
            s1 = randomSayiGetir();
            soru += s1;
            soru += " ";

            soru += islemTurleri.get(rndIslemNumber);

            soru += " ";
            s2 = randomSayiGetir();
            soru += s2;

            switch (islemTurleri.get(rndIslemNumber)){
                case "+":
                    sonuc = s1 + s2;
                    break;
                case "-":
                    sonuc =s1 - s2;
                case "*":
                    sonuc = s1 * s2;
                    break;
                case "/":
                    sonuc =s1 / s2;

            }
        }
        return soru;
    }

    private int randomSayiGetir(){
        rndSayiNumber = rndSayi.nextInt(10)+ 1;

        return rndSayiNumber;
    }
}